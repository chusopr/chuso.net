#!/usr/bin/perl

###############################################################################
#                                                                             #
#  webmailer.pl                                                               #
#                                                                             #
#  Envio de emails a traves de web                                            #
#                                                                             #
#  Programado por Jesus Perez Rey (h0m3r) <http://jesuspr.informaticos.org>   #
#                                                                             #
###############################################################################

use CGI;
use CGI::Carp qw(fatalsToBrowser);
my $query = new CGI;
$smail = '/usr/sbin/sendmail';
my $nremitente = $query->param("nfrom");
my $remitente = $query->param("from");
my $ndestinatario = $query->param("nto");
my $destinatario = $query->param("to");
my $asunto = $query->param("subject");
my $cuerpo = $query->param("body");
my $enviar = $query->param("enviar");
$fecha = `/bin/date -R`;

if ($destinatario ne $null)
{
    if ($enviar eq "si")
    {
	open (MAIL, "|$smail $destinatario");
        print MAIL "From: ";
	if ($nremitente ne $null)
        {
	    print MAIL "$nremitente <$remitente>\n";
	}
	else
        {
	    print MAIL "$remitente\n";
	}
        print MAIL "X-Mailer: Agujero Negro <http://agujero.com>\n";
        print MAIL "To: ";
	if ($ndestinatario ne $null)
        {
	    print MAIL "$ndestinatario <$destinatario>\n";
	}
	else
        {
	    print MAIL "$destinatario\n";
	}
        print MAIL "Subject: $asunto\n";
        print MAIL "Publicidad: Envia emails via web desde el Agujero Negro <http://agujero.com>\n";
        print MAIL "Content-Type: text/plain\n\n";
        print MAIL "$cuerpo\n\n";
        print MAIL "Este e-mail ha sido enviado desde Agujero Negro <http://agujero.com>\n";
        print MAIL "No se puede asegurar que la direccisn que figura como remitente ($remitente) sea la verdadera\n";
        print MAIL "El email fue enviado desde $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'}) con fecha $fecha";
        print MAIL "Envia tus correos electronicos a traves de web desde el Agujero Negro: http://agujero.com\n";
        print MAIL "_______________________________________________________________________________\n\n";
        print MAIL "This email has been sent through Agujero Negro <http://agujero.com>\n";
        print MAIL "It's not sure that the address that appers as sender ($remitente) is the real sender\n";
        print MAIL "The email has been sent from $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'}) at $fecha";
        print MAIL "Send your own e-mails through web at Agujero Negro: http://www.agujero.com\n";
        close(MAIL);
        print "Content-type: text/html\n\n";
        print "<HTML>\n";
        print "<HEAD><TITLE>E-mail enviado</TITLE></HEAD>\n";
        print "<BODY BGCOLOR=\"#FFFFFF\">\n";
        print "<P STYLE=\"font-family: Comic Sans MS, Verdana; font-weight: normal; font-size: 10pt; text-align: justify\">Seg&uacute;n parece, el email se env&iacute;o satisfactoriamente ;)</P><FORM><INPUT TYPE=\"button\" ONCLICK=\"history.go(-1)\" VALUE=\"Volver\"></FORM>\n";
        print "</BODY></HTML>\n";
    }
        else
    {
        if ($enviar eq "no")
        {

# Pagina de confirmacion
# Es posible que esta pagina no se vea correctamente con algunos navegadores
# (con, netscape-common-4.7-1.1 para Linux, por ejemplo, no se ve bien) ya
# que me fue imposible adaptarlo para todos los navegadores (por ejemplo,
# adaptarlo para netscape-common-4.7-1.1 hacia que no sirviera para Amaya y
# viceversa), asi que decidi adaptarlo a los estandares de la World Wide Web
# Consortium (W3C) <http://www.w3.org>, normativa que se supone que deberian
# aceptar todos los navegadores, asi que si en tu navegador no se ve bien es
# porque el navegador en cuestion no es compatible con la normativa de la W3C.
# La verdad es que pocos lo son y, si, no te sorprendas, Netscape e Internet
# Explorer tampoco.
#
# Amaya: el navegador de la W3C compatible con el HTML estandar:
# http://www.w3.org/Amaya
# W3C: http://www.w3.org
# Anybrowser (campagna a favor de la estandarizacion del HTML):
# http://www.anybrowser.org
#
# Bueno, despues de descargar mi ira contra los navegadores comerciales y
# dominantes, seguimos con el codigo xDDDD

            print "Content-Type: text/html\n\n";
            print "<HTML>\n";
            print "<HEAD>\n";
            print "<TITLE>Confirmaci&oacute;n</TITLE>\n";
            print "<STYLE>\n";
            print "body {\n";
            print "  background: white;\n";
            print "  font-family: Comic Sans MS, Verdana;\n";
            print "  color: black\n";
            print "}\n";
            print "\n";
            print "p {\n";
            print "  font-weight: normal;\n";
            print "  font-size: 10pt;\n";
            print "  text-align: justify;\n";
            print "  font-family: Comic Sans MS, Verdana\n";
            print "}\n";
            print "\n";
            print "a:link {\n";
            print "  color: #0000EE\n";
            print "}\n";
            print "\n";
            print "a:visited {\n";
            print "  color: #551A8B\n";
            print "}\n";
            print "\n";
            print "a:active {\n";
            print "  color: #0000EE\n";
            print "}\n";
            print "\n";
            print "a {\n";
            print "  text-decoration: none;\n";
            print "}\n";
            print "\n";
            print "input {\n";
            print "  font-size: 10pt\n";
            print "}\n";
            print "\n";
            print "</STYLE>\n";
            print "</HEAD>\n";
            print "<BODY>\n";
            print "<P>&Eacute;ste ser&aacute; el email enviado:</P>\n";
            print "<P>Destinatario: ";
	    if ($ndestinatario ne $null)
            {
		print "$ndestinatario &lt;$destinatario&gt;\n";
	    }
	    else
            {
		print "$destinatario\n";
	    }
            print "<BR>Remitente: ";
	    if ($nremitente ne $null)
            {
		print "$nremitente &lt;$remitente&gt;\n";
	    }
	    else
            {
		print "$remitente\n";
	    }
            print "<BR>Asunto: $asunto</P>\n";
            print "<P>Texto:\n";
            print "<BR><TEXTAREA ROWS=\"10\" COLS=\"62\">$cuerpo\n\n";
            print "Este e-mail ha sido enviado desde Agujero Negro <http://agujero.com>\n";
            print "No se puede asegurar que la direccion que figura como remitente ($remitente) sea la verdadera\n";
            print "El email fue enviado desde $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'}) con fecha $fecha";
            print "Envia tus correos electronicos a traves de web desde el Agujero Negro: http://agujero.com\n";
            print "_______________________________________________________________________________\n\n";
            print "This email has been sent through Agujero Negro <http://agujero.com>\n";
            print "It's not sure that the address that appers as sender ($remitente) is the real sender\n";
            print "The email has been sent from $ENV{'REMOTE_HOST'} ($ENV{'REMOTE_ADDR'}) at $fecha";
            print "Send your own e-mails through web at Agujero Negro: http://www.agujero.com\n</TEXTAREA></P>";
            print "<P><FORM METHOD=\"POST\" ACTION=\"http://127.0.0.1/cgi-bin/webmailer.pl\">\n";
	    print "<INPUT TYPE=\"HIDDEN\" NAME=\"nfrom\" VALUE=\"$nremitente\">\n";
            print "<INPUT TYPE=\"HIDDEN\" NAME=\"from\" VALUE=\"$remitente\">\n";
	    print "<INPUT TYPE=\"HIDDEN\" NAME=\"nto\" VALUE=\"$ndestinatario\">\n";
            print "<INPUT TYPE=\"HIDDEN\" NAME=\"to\" VALUE=\"$destinatario\">\n";
            print "<INPUT TYPE=\"HIDDEN\" NAME=\"subject\" VALUE=\"$asunto\">\n";
            print "<INPUT TYPE=\"HIDDEN\" NAME=\"body\" VALUE=\"$cuerpo\">\n";
            print "<INPUT TYPE=\"HIDDEN\" NAME=\"enviar\" VALUE=\"si\">\n";
            print "<P><INPUT TYPE=\"SUBMIT\" VALUE=\"Aceptar\"> <INPUT TYPE=\"button\" ONCLICK=\"history.go(-1)\" VALUE=\"Cancelar\">";
            print "</P></FORM></BODY></HTML>\n";
        }
        else
        {
            # Pagina que se muestra si se accede al CGI de forma incorrecta
	    print "Content-type: text/html\n\n";
	    print "<HTML>\n";
	    print "<HEAD><TITLE>Error</TITLE></HEAD>\n";
	    print "<BODY BGCOLOR=\"#FFFFFF\">\n";
	    print "<P STYLE=\"font-family: Comic Sans MS, Verdana; font-weight: nor\mal; font-size: 10pt; text-align: justify\">Valor incorrecto para la siguiente variable:<BR>";
	    print "\$enviar = $enviar</P>\n";
	    print "<FORM><INPUT TYPE=\"button\" ONCLICK=\"history.go(-1)\" VALUE=\"Volver\"></FORM></BODY></HTML>\n";
        }
    }
}
else
{
    # Pagina que se muestra si no se especifica un destinatario
    print "Content-type: text/html\n\n";
    print "<HTML>\n";
    print "<HEAD><TITLE>Error</TITLE></HEAD>\n";
    print "<BODY BGCOLOR=\"#FFFFFF\">\n";
    print "<P STYLE=\"font-family: Comic Sans MS, Verdana; font-weight: nor\mal; font-size: 10pt; text-align: justify\">No has especificado un destinatario</P>\n";
    print "<FORM><INPUT TYPE=\"button\" ONCLICK=\"history.go(-1)\" VALUE=\"Volver\"></FORM></BODY></HTML>\n";
}

#                                                                             #
#  Copyleft @ 2000 h0m3r                                                      #
#                                                                             #
