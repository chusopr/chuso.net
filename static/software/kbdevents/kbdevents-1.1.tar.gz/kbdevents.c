// Used by jprobes
#include <linux/kprobes.h>
// Used by input devices (i.e., keyboard)
#include <linux/input.h>
// GFP constants used by usermode helper setup
#include <linux/gfp.h>

// Module description
#define DRV_DESCRIPTION "Allows to execute commands for every key pressed"

// Module parameters
// Comand to be executed
static char *cmd = NULL;
// Verbose flag
static int verbose = 0;
// Key that triggers the event
static unsigned int keycode = 0;
// End of module parameters

// Jprobe to be inserted in kbd_event function from drivers/char/keyboard.c
// See Documentation/kprobes.txt for more info
static struct jprobe kev_jprobe;

// Main function that executes the command when a key is pressed
static void kbdevent(struct input_handle *handle, unsigned int event_type,
    unsigned int event_code, int value)
{
  // Checks if the keyboard event is a pressed key
  if ((event_type == EV_KEY) && (value == 1))
  {
    // If verbose is on, printk keycode
    if (verbose != 0)
      printk("kbdevent: pressed key %d\n", event_code);

    // If command is not null, try to run it
    if ((cmd != NULL) && ((keycode == 0) || (keycode == event_code)))
    {
      struct subprocess_info *ps;   // Struct with the info to launch the process
      char cmdstr[strlen(cmd) + 5]; // String that stores the command to be
                                    // executed and its arguments
                                    // Its length is the same as cmd plus the
                                    // chars needed to store the keycode
      char **argv;                  // Array of strings that stores the command
                                    // and each one of its arguments
      int argc;                     // Number of arguments

      // Build command with arguments, i.e.: "<command> <keycode>"
      snprintf(cmdstr, sizeof(cmdstr), "%s %d", cmd, event_code);
      // Split command line into argv array
      argv = argv_split(GFP_ATOMIC, cmdstr, &argc);

      // Setup the process struct that will be executed
      // GFP bitmask is GFP_USER so it's executed as an user process
      // and __GFP_NORETRY so it will no retry if it fails
      ps = call_usermodehelper_setup(argv[0], argv, NULL,
          GFP_USER | __GFP_NORETRY);
      // Execute the command
      call_usermodehelper_exec(ps, UMH_NO_WAIT);
    }
  }
  // Return to original function
  jprobe_return();
}

// Module loader
int init_module(void)
{
  // Variable that stores jprobe_register() return value to check
  // if it was succesfull
  int ret;

  // Set up jprobe
  // Set up kernel function to be jprobed
  kev_jprobe.kp.symbol_name = "kbd_event";
  // Function to insert before kernel function
  kev_jprobe.entry = (kprobe_opcode_t *) kbdevent;
  // End of jprobe setup

  // Register jprobe
  if ((ret = register_jprobe(&kev_jprobe)) < 0)
  {
    // If jprobe registering failed, show a message and exit
    // preventing module loading
    printk("Couldn't load kbdevent module, register_jprobe returned %d\n", ret);
    return -1;
  }

  printk("kbdevent module loaded\n");
  return 0;
}

// Module unloader
void cleanup_module(void)
{
  // Remove jprobe
  unregister_jprobe(&kev_jprobe);
  printk("kbdevent module unloaded\n");
}

// Module setup

// Dependencies
static const char __module_depends[]
__used
__attribute__((section(".modinfo"))) =
"depends=keyboard";

// License
MODULE_LICENSE("GPL");

// Parameters
module_param(cmd, charp, 0000);
MODULE_PARM_DESC(cmd, "Command to be executed on key press");
module_param(verbose, bool, 0000);
MODULE_PARM_DESC(verbose, "Do a printk() for each key pressed");
module_param(keycode, uint, 0000);
MODULE_PARM_DESC(keycode, "Keycode that triggers the event");
// End of module setup
